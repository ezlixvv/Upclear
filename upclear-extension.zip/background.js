// Herramienta "Arreglar subida": borra la cookie ttwid de TikTok.
chrome.runtime.onMessage.addListener((msg, _s, send) => {
  if (msg.type !== "fixUpload") return;
  (async () => {
    const cookies = await chrome.cookies.getAll({ name: "ttwid" });
    let removed = 0;
    for (const c of cookies) {
      if (!c.domain.endsWith("tiktok.com")) continue;
      const url = "https://" + c.domain.replace(/^\./, "") + c.path;
      await chrome.cookies.remove({ url, name: c.name, storeId: c.storeId });
      removed++;
    }
    send({ removed });
  })();
  return true; // respuesta asíncrona
});
