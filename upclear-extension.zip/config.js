// Edita estos valores con los de tu bot y tu servidor.
const CONFIG = {
  API_URL: "http://localhost:3000",   // donde corre server.js
  BOT_USERNAME: "UpClear_Bot",          // usuario de tu bot (sin @)
  SITE_URL: "https://tu-sitio.com/#planes"
};
