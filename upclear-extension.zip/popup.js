const $ = (s) => document.querySelector(s), $$ = (s) => [...document.querySelectorAll(s)];
const S = { session: null, active: true, mode: "check", pending: null };
const api = (p, o) => fetch(CONFIG.API_URL + p, o).then((r) => r.json());
const save = (o) => chrome.storage.local.set(o);

function go(v) {
  $$(".view").forEach((e) => (e.hidden = e.id !== "v-" + v));
  $$("nav button").forEach((b) => b.classList.toggle("on", b.dataset.go === v));
}
function render() {
  const on = !!S.session;
  $("#who").textContent = on ? S.session.user.name : "Invitado";
  $("#name2").textContent = on ? S.session.user.name : "";
  $("#pill").textContent = on ? "Conectado" : "Sin sesión";
  $("#pill").classList.toggle("ok", on);
  $$(".gate").forEach((g) => g.classList.toggle("locked", !on));
  $("#in").hidden = on; $("#out").hidden = !on;
  $("#pend").hidden = on || !S.pending;
  $("#plan").textContent = (on && S.session.user.plan) || "Sin plan activo";
  $("#active").checked = S.active;
  $$("input[name=mode]").forEach((r) => (r.checked = r.value === S.mode));
  $("#stat").textContent = S.active ? "Activo" : "Apagado";
  $("#dot").classList.toggle("off", !S.active);
}
async function checkPending() {
  if (!S.pending) return;
  try {
    const r = await api("/auth/status?code=" + S.pending);
    if (r.ok) {
      S.session = { token: r.token, user: r.user }; S.pending = null;
      await save({ session: S.session, pending: null });
    }
  } catch { $("#loginmsg").textContent = "No pude conectar con el servidor."; }
}

$$("[data-go]").forEach((b) => (b.onclick = () => go(b.dataset.go)));
$("#active").onchange = (e) => { S.active = e.target.checked; save({ active: S.active }); render(); };
$$("input[name=mode]").forEach((r) => (r.onchange = () => { S.mode = r.value; save({ mode: S.mode }); }));
$("#fix").onclick = async () => {
  const r = await chrome.runtime.sendMessage({ type: "fixUpload" });
  $("#msg").textContent = r.removed ? "Listo. Recarga TikTok e intenta subir de nuevo." : "No encontré la cookie. Abre TikTok e inténtalo otra vez.";
};
$("#login").onclick = async () => {
  try {
    const { code } = await api("/auth/start", { method: "POST" });
    S.pending = code; await save({ pending: code });
    chrome.tabs.create({ url: `https://t.me/${CONFIG.BOT_USERNAME}?start=${code}` });
    $("#loginmsg").textContent = ""; render();
  } catch { $("#loginmsg").textContent = "No pude conectar con el servidor. Revisa config.js."; }
};
$("#verify").onclick = async () => { await checkPending(); render(); };
$("#logout").onclick = async () => { S.session = null; await save({ session: null }); render(); };
$("#site").href = CONFIG.SITE_URL;

(async () => {
  Object.assign(S, await chrome.storage.local.get({ session: null, active: true, mode: "check", pending: null }));
  if (!S.session) await checkPending();
  render();
  setInterval(async () => { if (!S.session && S.pending) { await checkPending(); render(); } }, 2500);
})();
