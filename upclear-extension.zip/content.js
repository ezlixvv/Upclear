// Revisión de calidad: solo corre con sesión iniciada, interruptor activo y modo "check".
let enabled = false;
const sync = () => chrome.storage.local.get({ active: true, mode: "check", session: null },
  (v) => (enabled = v.active && v.mode === "check" && !!v.session));
sync();
chrome.storage.onChanged.addListener(sync);

document.addEventListener("change", async (e) => {
  const el = e.target;
  if (!enabled || !(el instanceof HTMLInputElement) || el.type !== "file") return;
  const f = el.files && el.files[0];
  if (!f || !f.type.startsWith("video/")) return;
  show(await analyze(f));
}, true);

function analyze(file) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement("video");
    v.muted = true; v.src = url;
    const fail = () => { URL.revokeObjectURL(url); resolve(null); };
    v.onerror = fail;
    v.onloadedmetadata = () => {
      const info = { name: file.name, w: v.videoWidth, h: v.videoHeight, mbps: (file.size * 8) / v.duration / 1e6, fps: null };
      if (!v.requestVideoFrameCallback) { URL.revokeObjectURL(url); return resolve(info); }
      let n = 0, t0 = null, t1 = 0, done = false;
      const finish = () => {
        if (done) return; done = true; v.pause(); URL.revokeObjectURL(url);
        if (t1 > t0) info.fps = Math.round((n - 1) / (t1 - t0));
        resolve(info);
      };
      const tick = (_now, m) => {
        if (t0 === null) t0 = m.mediaTime;
        n++; t1 = m.mediaTime;
        t1 - t0 < 1 ? v.requestVideoFrameCallback(tick) : finish();
      };
      v.requestVideoFrameCallback(tick);
      v.play().catch(finish);
      setTimeout(finish, 5000);
    };
  });
}

function show(r) {
  document.getElementById("upclear-toast")?.remove();
  const box = document.createElement("div");
  box.id = "upclear-toast";
  box.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;max-width:340px;padding:14px 16px;border-radius:12px;background:#120b1f;color:#f3ecff;font:14px/1.45 system-ui,sans-serif;box-shadow:0 8px 30px #0008;border:1px solid #3b2a5a";
  const line = (t, bold) => { const p = document.createElement("div"); p.textContent = t; if (bold) p.style.fontWeight = "700"; box.append(p); };
  const btn = (t, fn) => {
    const b = document.createElement("button"); b.textContent = t; b.onclick = () => fn(b);
    b.style.cssText = "margin:10px 14px 0 0;background:none;border:0;color:#c084fc;cursor:pointer;padding:0;font:inherit";
    return b;
  };
  let cmd = null;
  if (!r) line("UpClear: no pude leer este video.", true);
  else {
    const tips = [];
    if (Math.min(r.w, r.h) < 1080) tips.push("Resolución menor a 1080p: exporta en 1080×1920 desde tu editor. TikTok no la mejora.");
    if (r.h < r.w) tips.push("Es horizontal: en TikTok se ve mejor en vertical 9:16.");
    if (r.fps && r.fps > 30) tips.push(`Está en ${r.fps} fps: prueba exportar a 30 fps. Muchos creadores reportan que se ve más limpio tras la recompresión.`);
    if (r.fps && r.fps < 24) tips.push("Menos de 24 fps: el movimiento se verá entrecortado.");
    if (r.mbps < 10) tips.push(`Bitrate de ${r.mbps.toFixed(1)} Mbps: exporta con 10 a 20 Mbps.`);
    line(tips.length ? "UpClear: conviene mejorar esto" : "UpClear: listo para subir", true);
    line(`${r.w}×${r.h} · ${r.fps ?? "?"} fps · ${r.mbps.toFixed(1)} Mbps`);
    tips.forEach((t) => line("• " + t));
    if (tips.length) {
      const n = r.name.replace(/"/g, "");
      cmd = `ffmpeg -i "${n}" -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2"` +
        `${r.fps && r.fps > 30 ? " -r 30" : ""} -c:v libx264 -preset slow -crf 16 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart "upclear-${n.replace(/\.[^.]+$/, "")}.mp4"`;
    }
  }
  if (cmd) box.append(btn("Copiar comando ffmpeg", async (b) => {
    try { await navigator.clipboard.writeText(cmd); b.textContent = "Copiado"; } catch { b.textContent = "No pude copiar"; }
  }));
  box.append(btn("Cerrar", () => box.remove()));
  document.body.append(box);
  setTimeout(() => box.remove(), 30000);
}
